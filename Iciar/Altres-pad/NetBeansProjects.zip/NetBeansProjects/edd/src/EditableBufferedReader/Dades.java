/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package EditableBufferedReader;

import java.lang.Integer;


/**
 *
 * @author lpadusr11
 */
public class Dades {
    public static final int RIGHT = Integer.MIN_VALUE +2;
    public static final int LEFT = Integer.MIN_VALUE + 1;
    public static final int BACKSPACE = 127;
    public static final int FIN = Integer.MIN_VALUE + 52;
    public static final int HOME = Integer.MIN_VALUE + 49;
    public static final int DELETE = Integer.MIN_VALUE + 51;
    public static final int INS = Integer.MIN_VALUE + 50;
    public static final int MIN = Integer.MIN_VALUE;

    public Dades() {

    }
    
}

