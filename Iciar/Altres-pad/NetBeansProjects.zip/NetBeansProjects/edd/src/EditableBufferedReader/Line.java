/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package EditableBufferedReader;

/**
 *
 * @author lpadusr11
 */
public class Line {
    private String str = "";
    private boolean ins = false;
    private int cursor = 0, max= 1;

    public Line() {
    }
    
    public void right(){
        cursor ++;
    }
    public void left(){
        cursor --;
    }
    public void delete(){
        str=str.substring(0, cursor-1)+str.substring(cursor+1);
    }
    public void backspace(){
        str=str.substring(0, cursor-2)+str.substring(cursor);
        cursor --;
        
        //si borres el primer, cursor en negtiu
    }
    public void toggle(){
        
    }
    public void add(char i){
        str= str + i;
        cursor++;
        
    }
    public void home(){
        
    }
    public void fin(){
        
    }
    public String toString(){
        return str;
    }
}
