/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package chat;

/**
 *
 * @author lpadusr11
 */
public class Server {   
    public static void main(String[] args) {
        // TODO code application logic here
        MyServerSocket ss= new MyServerSocket(Integer.parseInt(args[0]));
        
        while (true){
            final MySocket s = ss.accept();
            new Thread(){
                public void run(){
                    String line;
                    while ((line=s.readline()) != null){
                        s.println(line);
                    }
                    s.close();
                }
            }.start();
        }
    }
}
