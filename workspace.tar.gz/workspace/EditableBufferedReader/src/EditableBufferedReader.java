import java.io.*;
public class EditableBufferedReader extends BufferedReader{
	
	public EditableBufferedReader(Reader r){
		super(r);
	}
	
	private static void setRaw() {
	    // put terminal in raw mode
		try {
			String[] cmd = {"/bin/sh", "-c", "stty raw </dev/tty"};
			Runtime.getRuntime().exec(cmd);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	  }
	private static void unsetRaw() {
	    // put terminal in raw mode
		try {
			String[] cmd = {"/bin/sh", "-c", "stty cooked </dev/tty"};
			Runtime.getRuntime().exec(cmd);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	  }
	
	/**
	*  RIGHT: Esc [ C
	*  LEFT: Esc [ D
	*  HOME: Esc O H, Esc [ 1 ~
	*  END: Esc O F, Esc [ 4 ~
	*  DEL: Esc [ 3 ~
	*  INS: Esc [ 2 ~
	 * @throws IOException 
	*/
	public int read() throws IOException{ // !!!!!!!!!!!!!!!!!CAL CANVIAR EL RETURNS PERQUE ESTIGUIN DINS UN RANG CORRECTE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		int caracter = 0;
		final int RIGHT = Integer.MIN_VALUE;
		final int LEFT = Integer.MIN_VALUE+1;
		final int HOME = Integer.MIN_VALUE+2;
		final int END = Integer.MIN_VALUE+3;
		final int DEL = Integer.MIN_VALUE+4;
		final int INS = Integer.MIN_VALUE+5;
		final int BKSP = Integer.MIN_VALUE+6;
		
		while(caracter !='\n' || caracter != '\r'){
			caracter = super.read();
			int resultat=0;
			if(caracter == 27){
				int instruccio = super.read();
				if(instruccio=='['){
					switch(super.read()){
						case 'C':
							resultat = RIGHT ; 
							break;
						case 'D':
							resultat = LEFT;
							break;
						case '4':
							if(super.read()=='~'){
								resultat = END;
							}
							break;
						case '1':
							if(super.read()=='~'){
								resultat = HOME;
							}
							break;
						case '3':
							if(super.read()=='~'){
								resultat = DEL;
							}
							break;
						case '2':
							if(super.read()=='~'){
								resultat = INS;
							}
							break;
					}
				}else if(instruccio =='O'){
					switch(super.read()){
					case 'H':
						resultat = HOME;
						break;
					case 'F':
						resultat = END;
						break;
					}
				}
				return resultat;
			}else if (caracter== '\b'){
				return BKSP;
			}else{			
				return caracter;
			}
		}
		return '\n';
	}
	
	public String readLine() throws IOException{
		int llegir = read();
		while(llegir = read() != )
		return null;
		
	}
}
