import java.io.*;

import static java.lang.System.in;

public class proba {
	
	private static void setRaw() {
	    // put terminal in raw mode
		try {
			String[] cmd = {"/bin/sh", "-c", "stty raw </dev/tty"};
			Runtime.getRuntime().exec(cmd);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	  }
	public static void main(String[] args){
		setRaw();
	}
}

