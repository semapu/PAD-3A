import java.io.IOException;
import java.io.*;
public class unsetraw {
	private static void unsetRaw() {
	    // put terminal in raw mode
		try {
			String[] cmd = {"/bin/sh", "-c", "stty cooked </dev/tty"};
			Runtime.getRuntime().exec(cmd);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	  }
	public static void main(String[] args){
		unsetRaw();
	}

}
